package fr.miroff.FouleProject;

public class Bandits {
}
